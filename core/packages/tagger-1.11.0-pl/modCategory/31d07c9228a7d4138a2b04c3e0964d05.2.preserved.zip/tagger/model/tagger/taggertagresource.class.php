<?php
/**
 * @property int $tag
 * @property int $resource
 *
 * @property TaggerTag $Tag
 * @property modResource $Resource
 *
 * @package tagger
 */
class TaggerTagResource extends xPDOObject {}
?>