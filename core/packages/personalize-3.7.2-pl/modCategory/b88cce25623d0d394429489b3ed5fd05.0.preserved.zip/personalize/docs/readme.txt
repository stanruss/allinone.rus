--------------------
Snippet: Personalize
--------------------
Author: Bob Ray <http://bobsguides.com>

A snippet for showing one chunk to logged-in users and
another chunk to anonymous users.

Documentation:
See tutorial at http://bobsguides.com/personalize-tutorial.html

Also: Edit the Personalize snippet and click on the Properties tab.
      Click on the plus sign next to any property to see its description.

Bugs and Requests:
https://github.com/BobRay/Personalize/issues

